
package org.grails.plugins.grailsant


class UnzipException extends RuntimeException {
	String message
	String defaultMessage
	String fileName
}
